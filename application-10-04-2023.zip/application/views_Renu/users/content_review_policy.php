<div id="privacy-content" class="container">
    <div class="col-sx-12 col-sm-12 col-md-12" style="border-left: 3px solid cadetblue; padding: 0px 25px;">
        <div class="static-content">
            <div class="bloginfo">
                <h3 style="margin-bottom: 0px;margin-top:20px;color: #0086b2!important;font-weight: 600;">Content Review Policy (CRP)</h3>
            </div>
            <div class="heading-underline" style="width: 200px;">
                <div class="left"></div><div class="right"></div>
             </div>
            <div class="bloginfo">
                <p>This PMRDA website is an important tool for disseminating the information to the masses being served by the organization. It is therefore required to keep the content on the Website current and up-to-date and hence there is a need for the Content Review Policy. Since the scope of the content is huge, different Review Policies are defined for the diverse content elements.</p>
                <p>The Review Policy is based on different type of content elements, its validity and relevance as well as the archival policy. The matrix below gives the Content Review Policy:</p>
            </div>
            
         </div>
    </div>
  </div>