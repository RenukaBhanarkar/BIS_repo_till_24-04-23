
<div id="privacy-content" class="container">
    <div class="col-sx-12 col-sm-12 col-md-12" style="border-left: 3px solid cadetblue; padding: 0px 25px;">
        <div class="static-content">
            <div class="bloginfo">
                <h3 style="margin-bottom: 0px;margin-top:20px;color: #0086b2!important;font-weight: 600;">About Exchange Forum</h3>
            </div>
            <div class="heading-underline" style="width: 200px;">
                <div class="left"></div><div class="right"></div>
             </div>
            <div class="bloginfo">
                
                <img src="<?php echo base_url(); ?>assets/images/indexBanner.jpeg" id="about_new">
                <p>IS is the National Standard Body of India established under the BIS Act 2016 for the harmonious development of the activities of standardization, marking and quality certification of goods and for matters connected therewith or incidental thereto BIS has been providing traceable and tangible benefits to the national economy in a number of ways – providing safe reliable quality goods; minimizing health hazards to consumers; promoting exports and imports substitute; control over proliferation of varieties etc. through standardization, certification and testing. IS is the National Standard Body of India established under the BIS Act 2016 for the harmonious development of the activities of standardization, marking and quality certification of goods and for matters connected therewith or incidental thereto BIS has been providing traceable and tangible benefits to the national economy in a number of ways – providing safe reliable quality goods; minimizing health hazards to consumers; promoting exports and imports substitute; control over proliferation of varieties etc. through standardization, certification and testing.</p>
                
            </div>
         </div>
    </div>
  </div>
