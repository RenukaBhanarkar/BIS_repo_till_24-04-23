    <!-- Begin Page Content -->
    <div class="container">
        <!-- Content Row -->
      
        <div class="row">
            <div class="col-12 mt-3">
            <div class="card card-body">
                <table id="example" class="hover table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Subject</th>
                            <th>Name of proposer</th>
                            <th>Organization Type</th>
                            <th>Date of receipt</th>
                            <th>Current Stage</th>
                            <th>Concerned Bis Department</th>
                           
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                                <tr>
                                 <td>1</td>
                                 <td>Subject</td>
                                 <td>Name of proposer</td>
                                 <td>Organization Type</td>
                                 <td>Date of receipt</td>
                                 <td>Current Stage</td>
                                 <td>Concerned Bis Department</td>
                                 <td class="d-flex border-bottom-0">
                                    <button onClick="location.href='#'" class="btn btn-primary btn-sm mr-2"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                    <button onClick="location.href='#'" class="btn btn-info btn-sm mr-2"><i class="fa fa-edit" aria-hidden="true"></i></button>
                                    <button onClick="location.href='#'" class="btn btn-danger btn-sm mr-2"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                 </td>
                                 </tr>
 
                    </tbody>
                </table>
            </div>    
          </div>
        </div>
       </div>
    <!-- /.container-fluid -->

