<style>
    .heading-underline .right{
        width:10%;
    }
</style>
<div id="privacy-content" class="container">
    <div class="col-sx-12 col-sm-12 col-md-12" style="border-left: 3px solid cadetblue; padding: 0px 25px;">
        <div class="static-content">
            <div class="bloginfo">
                <h3 style="margin-bottom: 0px;margin-top:20px;color: #0086b2!important;font-weight: 600;">Hyperlinking Policy</h3>
            </div>
            <div class="heading-underline" style="width: 200px;">
                <div class="left"></div><div class="right"></div>
             </div>
            <div class="bloginfo">
                <h4 style="margin-bottom: 0px;margin-top:20px;font-size: 19px;font-weight: 700;">Links to external websites/portals</h4>
                <p>At many places in this website, you shall find links to other websites/portals. The links have been placed for your convenience. PMRDA is not responsible for the contents and reliability of the linked websites and does not necessarily endorse the views expressed in them. Mere presence of the link or its listing on this Portal should not be assumed as endorsement of any kind. We cannot guarantee that these links will work all the time and we have no control over availability of linked pages.</p>
                <p>When you select a link to an outside website, you are leaving the PMRDA website and are subject to the privacy and security policies of the owners/sponsors of the outside website. PMRDA cannot authorize the use of copyrighted materials contained in linked websites. Users are advised to request such authorization from the owner of the linked website. PMRDA does not guarantee that linked websites comply with Indian Government Web Guidelines.</p>
            </div>
         </div>
    </div>
  </div>