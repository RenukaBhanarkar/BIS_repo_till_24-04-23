
<div class="container">
<div class="feedback_content">
<div class="bloginfo">
                <h3 style="margin-bottom: 0px;margin-top:20px;color: #0086b2!important;font-weight: 600;">Feedback Form</h3>
            </div>
            <div class="heading-underline" style="width: 200px;">
                <div class="left"></div><div class="right"></div>
             </div>
    <div class="row">
            <div class="mb-2 col-md-4">
                <label class="d-block text-font">Name</label>
                <input type="text" class="form-control input-font" name="name" id="name" placeholder="Enter Title"required="">
            </div>
            <div class="mb-2 col-md-4">
                <label class="d-block text-font">Mobile Number</label>
                <input type="text" class="form-control input-font" name="name" id="name" placeholder="Enter Mobile Number" required="">
                
            </div>
            <div class="mb-2 col-md-4">
                <label class="d-block text-font">Email</label>
                <input type="text" class="form-control input-font" name="name" id="name" placeholder="Enter Email" required="">
                
            </div>
            <div class="mb-2 col-md-4">
                <label class="d-block text-font">Subject</label>
                <input type="text" class="form-control input-font" name="name" id="name" placeholder="Enter Subject" required="">
                
            </div>
            <div class="mb-2 col-md-8">
                <label class="d-block text-font">Description</label>
                <textarea type="text" class="form-control input-font" name="name" id="name" placeholder="Enter Description" required=""></textarea>
                
            </div>
    </div>
    <div class="row">
            <div class="col-md-12 p-3 text-end">
                <button class="btn btn-primary" type="button" onclick="return validateForm();">Submit</button>
                <button class="btn btn-danger" type="button" onclick="location.href='feedback'">Cancel</button>
                <button class="btn btn-warning" type="reset" fdprocessedid="42ijcx">Reset</button>
            </div>
    </div>
    </div>
</div>